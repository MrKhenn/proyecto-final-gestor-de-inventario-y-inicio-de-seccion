# PRO-GAMER---Web-Page
Pagina Web de Video Juegos
PRO GAMER combina un estilo nostálgico con un toque moderno. La paleta de colores incluye tonos oscuros, evocando la estética de los videojuegos clásicos. Elementos gráficos   referencias a consolas  decoran la página, creando un ambiente envolvente para los amantes de la vieja escuela.
