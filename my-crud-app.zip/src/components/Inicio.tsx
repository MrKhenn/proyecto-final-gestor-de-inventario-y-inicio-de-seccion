const Inicio: React.FC = () => {
    return (
      <div>
        <h1>Sistema de Registros - CRUD App</h1>
        <p>Maneja tus registros de forma facil y sencilla con nuestro sistema de CRUD APP</p>
      </div>
    );
  }
  
  export default Inicio;
  