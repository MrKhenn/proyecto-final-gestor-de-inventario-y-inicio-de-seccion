import axios from 'axios';

const API_URL = 'http://localhost:4000/api/records';

export interface Record {
  _id: string;
  name: string;
  description: string;
  date: string;
  organizer: string;
}

// Función para obtener los registros
export const getRecords = async (): Promise<Record[]> => {
  try {
    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    console.error('Error al obtener los registros:', error);
    throw error;
  }
};

// Función para eliminar un registro
export const deleteRecord = async (id: string): Promise<void> => {
  try {
    await axios.delete(`${API_URL}/${id}`);
  } catch (error) {
    console.error('Error al eliminar el registro:', error);
    throw error;
  }
};

// Función para actualizar un registro
export const updateRecord = async (id: string, updatedRecord: Partial<Record>): Promise<Record> => {
  try {
    const response = await axios.put(`${API_URL}/${id}`, updatedRecord);
    return response.data;
  } catch (error) {
    console.error('Error al actualizar el registro:', error);
    throw error;
  }
};
