import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Inicio from './components/Inicio';
import CreateRecord from './components/CreateRecord';
import EditRecord from './components/EditRecord';
import RecordList from './components/RecordList';
import './App.css';

const App: React.FC = () => {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li><a href="/">Inicio</a></li>
            <li><a href="/create">Crear Nuevo Evento</a></li>
            <li><a href="/records">Evento</a></li>
          </ul>
        </nav>

        <Routes>
          <Route path="/" element={<Inicio />} />
          <Route path="/create" element={<CreateRecord />} />
          <Route path="/edit/:id" element={<EditRecord />} />
          <Route path="/records" element={<RecordList />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
